#!/bin/bash
setxkbmap -model pc105 -layout de
