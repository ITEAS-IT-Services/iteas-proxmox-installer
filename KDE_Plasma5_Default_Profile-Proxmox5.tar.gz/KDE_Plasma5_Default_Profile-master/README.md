Folgende Dinge sind im Profil angepasst worden:

- Plasmadesktop Widgets
- Größen und Positionen
- Design und Farben angepasst
- Farbschema etwas dunkler in Home verfügbar (kann in Systemsettings importiert werden)
- Datei, Auflistungen, Vorschau
- Programmprofile (Kmouth, Libreoffice, nano, zsh, Konsole, Kate, Desktopbeschleunigung...)
- Anpassung Schriftgrößen, Art
- ENV
- Menüs (sind natürlich Programminstallationsabhänging)
- System bedingte Einstellungen wie Energieverwaltung, Autostart, Startverhalten usw. wurden auch angepasst
- uvm.
